import './Home.css';
import image1 from '../assets/sq1.png';
import image2 from '../assets/sq2.png';
import React, {Component, useState} from 'react';
import axios from 'axios';

function Home() {

    async function getResultImage() {
        try{
            const config = { headers: { 'Content-Type': 'multipart/form-data' } };
            let formData = new FormData();
            
            formData.append("arrayOfFilesName", styleImage, "style_image");
            // formData.append("arrayOfFilesName", contentImage, "content_image");
            console.log(formData);
            const response = await axios.post("http://192.168.1.76:105/combine",{data:formData}, config);
            console.log(response);
            // setTop(response);        
        }catch(error){
            console.log(error.response);
        }

    }
    const imageClick = () => {
        console.log("clicked");
    }

    const handleChange = (event) => {
        setThreshold(event.target.value);
    }

    const [threshold, setThreshold] = useState(0.5);
    const [styleImage, setStyleImage] = useState(null);
    const [contentImage, setContentImage] = useState(null);
    const fileChangedHandler = event => {


        let file = event.target.files[0];
        let reader = new FileReader();
        /**Capture filename */

        console.log(file);
        reader.onload = function(e) {
            if (event.target.id=="style-input"){
                setStyleImage(e.target.result)  
            }
            if (event.target.id=="content-input"){
                setContentImage(e.target.result)  
            }              
        };
        reader.readAsDataURL(event.target.files[0]);
    

        if (file.type != "image/png" && file.type !="image/jpg" ) {
          window.alert("File does not support. You must use .png or .jpg ");
          return false;
       }
       if (file.size > 1e+7) {
         window.alert("Please upload a file smaller than 1 MB");
         return false;
       }
       
      };

    return (
        <div className="page">      
        <div className="NavWrapper">
        <div className="NavBar">
        <div className="home-links">
            <span className="home-text03 navbarLink" ><a href="#section1" class="btn" style={{color:`#000000`, marginRight:`0rem`}}>HOME</a></span>
            [View the tool in full screen for right functioning...]
          </div>
          
          </div>
          </div>
          <div id="#section1">       
          {/* <img
              alt="image"
              src={image1}
              style={{transform:`rotate(-12deg)`, position:`relative`, marginLeft:`10rem`,marginTop:`10rem`,opacity: `0.1`}}
              className="style-image"
              onClick={() => imageClick()}
            /> */}
            <input className="range" type="range" onChange={handleChange}/>
            <button className="button-7" role="button" onClick={getResultImage}>calculate</button>
            <input
        type="file"
        id="style-input"
        name="myImage"
        style={{transform:`rotate(-12deg)`, position:`relative`, marginLeft:`18rem`,marginTop:`2rem`,opacity: `1`}}
        onChange={fileChangedHandler}
      />
      
            <input
            id="content-input"
        type="file"
        name="myImage"
        style={{transform:`rotate(12deg)`, position:`relative`, marginLeft:`12%`,marginTop:`5%`,opacity: `1`}}
        onChange={fileChangedHandler}
      />
      


            {/* <img
              alt="image"
              src={image2}
              style={{
                transform:`rotate(12deg)`,position:`relative`,marginLeft:`-2%`,marginTop:`-20rem`,scale:`0.9`,opacity: `0.1`}}
              className="cotent-image"
              onClick={() => imageClick()}
              /> */}
               
            </div>
           
        </div>
    );

}

export default Home;